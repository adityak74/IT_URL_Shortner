<?php


echo '<meta http-equiv="refresh" content="0;'.$link[0]->long_url.'">';

?>